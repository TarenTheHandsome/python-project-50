import json


def generate_diff(filepath1, filepath2):
    dict1 = json.load(open(f'{filepath1}'))
    dict2 = json.load(open(f'{filepath2}'))
    result = ''
    for key in dict1:
        if key not in dict2:
            result += str(f'- {key}: {dict1[key]}\n')
        elif key in dict2:
            if dict1[key] == dict2[key]:
                result += str(f' {key}: {dict1[key]}\n')
            else:
                result += str(f'- {key}: {dict1[key]}\n')
                result += str(f'+ {key}: {dict2[key]}\n')
    for key in dict2:
        if key not in dict1:
            result += str(f'+ {key}: {dict2[key]}\n')

    return result

# print(generate_diff('/Users/roman/Documents/Projects/python-project-50/files/file1.json', '/Users/roman/Documents/Projects/python-project-50/files/file2.json'))

# dict1 = json.load(open('/Users/roman/Documents/Projects/python-project-50/files/file1.json'))
# dict2 = json.load(open('/Users/roman/Documents/Projects/python-project-50/files/file2.json'))