### Hexlet tests and linter status:
[![Actions Status](https://github.com/TarenTheHandsome/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/TarenTheHandsome/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/9c2a0c0fa58d3e67cbeb/maintainability)](https://codeclimate.com/github/TarenTheHandsome/python-project-50/maintainability)

